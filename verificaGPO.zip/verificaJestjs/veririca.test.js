const verifica = require('./verifica');

test('test albero in 4L83R0', () => {
    let parola = "albero";
    expect(verifica(parola)).toBe("4L83R0");
});

//il test funziona


const calcola = require("./verifica");
test('test funzione calcola', () => {
    expect(calcola('sin(x) + 1', 1.5)).toBeCloseTo(1.9);
});